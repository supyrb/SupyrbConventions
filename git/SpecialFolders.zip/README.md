# Introduction

Copyright Supyrb- Gaschka und Deml GbR 2016-2018  
Take a deep breath and dive into the sea of excellence!

# Getting started

* Read and follow the information here: https://github.com/supyrb/SupyrbConventions
